from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

Motor_A = Motor(Port.A,Direction.CLOCKWISE)
Motor_B = Motor(Port.B,Direction.COUNTERCLOCKWISE)
drive_base = DriveBase(Motor_A, Motor_B, 49.5, 120)
right_attachment = Motor(Port.D)
left_attachment = Motor(Port.C)
right_color_sensor = ColorSensor(Port.F)
left_color_sensor = ColorSensor(Port.E)

drive_base.use_gyro(True)

drive_base.straight(distance=10) #Starting from Right base going straight
drive_base.turn(angle=-23)
drive_base.straight(distance=340) #Starting from Right base going straight
drive_base.turn(angle=34)
drive_base.straight(distance=105)
drive_base.turn(angle=-23)
drive_base.straight(distance=110)
drive_base.turn(angle=32)
drive_base.straight(distance=160)
drive_base.straight(distance=-20)
drive_base.turn(angle=90)
#drive_base.stop()


